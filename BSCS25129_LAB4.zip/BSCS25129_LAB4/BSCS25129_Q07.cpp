#include<iostream>

using namespace std;

int main6()
{
	float num = 0;
	int CeilValue = 0;
	int FloorValue = 0;

	cout << "Enter number: ";
	cin >> num;

	if (num > 0)
	{
		CeilValue = num + 1;
		cout << "Ceil Value: " << CeilValue << endl;

		FloorValue = num;
		cout << "Floor Value: " << FloorValue << endl;
	}
	else
	{
		CeilValue = num;
		cout << "Ceil Value: " << CeilValue << endl;

		FloorValue = num - 1;
		cout << "Floor Value: " << FloorValue << endl;
	}

	return 0;
}