#include<iostream>

using namespace std;

int main4()
{
	int i = 0;
	int  num = 0;
	int startingIndex = 0;
	int endingIndex = 0;

	cout << "Enter starting and ending index: ";
	cin >> startingIndex >> endingIndex;
	cout << "Enter N: ";
	cin >> num;
	cout << endl;

	i = startingIndex;

	while (i >= endingIndex)
	{
		cout << num << " x " << i << " = " << num * i << endl;
		i--;
	}
	
	return 0;
}