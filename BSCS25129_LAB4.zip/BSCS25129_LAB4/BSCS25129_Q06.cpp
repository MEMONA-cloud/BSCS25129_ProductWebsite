#include<iostream>

using namespace std;

int main5()
{
	int num = 0;
	int evenCount = 0;
	int oddCount = 0;

	cout << "Enter your number: ";
	cin >> num;
	
	while (num != -1)
	{

		if (num % 2 == 0)
		{
			evenCount = ++evenCount;
		}

		else
		{
			oddCount = ++oddCount;
		}

		cin >> num;

	}
	cout << "Even Count: " << evenCount << endl;
	cout << "Odd Count: " << oddCount << endl;


	return 0;
}