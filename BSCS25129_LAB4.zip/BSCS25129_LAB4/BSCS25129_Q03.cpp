#include<iostream>

using namespace std;

int main2()
{
	int i = 1;
	int num = 0;
	char ch = 0;
	int N = 0;
	int ans = 0;


	cout << "Enter N: ";
	cin >> N;
	cout << "Enter character input: ";

	while (i <= N)
	{
		cin >> ch;

		num = ch - 48;
		ans = ans * 10 + num;
		i++;
	}


	return 0;
}