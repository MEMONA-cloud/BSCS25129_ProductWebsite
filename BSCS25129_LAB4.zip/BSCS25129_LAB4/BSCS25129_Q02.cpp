#include<iostream>

using namespace std;

int main1()
{
	int  num = 0;
	int i = 0;
	int secretnumber = 0;
	srand(time(0));
	secretnumber = rand() % 1000;

	cout << secretnumber << endl;

	while (i < 5)
	{
		cout << "Enter number between 1 and 1000: ";
		cin >> num;

		if (num < secretnumber)
		{
			cout << "Guess too low" << endl;
		}
		else if(num > secretnumber)
		{
			cout << "Guess too high" << endl;
		}
		else if (num == secretnumber)
		{
			cout << "Congratulations, You Guessed the Secret Number: " << endl;
			break;
		}
		i++;
	}

	if (i == 5)
	{
			cout << endl << "Skill Issue" << endl;
    }

	return 0;
}