#include <iostream>

using namespace std;

int main()
{
	int num1 = 0;
	int num2 = 1;
	int N = 2;
	int month = 0;
	int result = 0;

	cout << "Enter Month: ";
	cin >> month;

	while (N <= month)
	{
		result = num1 + num2;
		num1 = num2;
		num2 = result;
		N++;
	}

	cout << "Total Pairs After " << month << " months are: " << result;
	return 0;
}